// Garrick Morley
// ISYS 221-001
// Assignment #6 - To-Do List
// Due: 10/31/2021

// Connect all of the classes and fragments
package com.zybooks.favoritefood;

// Import the necessary androidx package
import androidx.appcompat.app.AppCompatActivity;

// Import the rest of the necessary android packages
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;

// Main class that runs everything
public class MainActivity extends AppCompatActivity {


    @Override
    // Set the first screen to the fragment_main.xml setup with the four website buttons and the one .xml file link
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);

        // Create and link the Taco Bell website button from the main fragment that activates when clicked
        Button tacobell = (Button) findViewById(R.id.button1);
        tacobell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToUrl("https://www.tacobell.com");
            }
        });

        // Create and link the Wendy's website button from the main fragment that activates when clicked
        Button wendys = (Button) findViewById(R.id.button2);
        wendys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToUrl("https://wendys.com");
            }
        });

        // Create and link the Subway website button from the main fragment that activates when clicked
        Button subway = (Button) findViewById(R.id.button3);
        subway.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToUrl("https://subway.com");
            }
        });

        // Create and link the Mancinos website button from the main fragment that activates when clicked
        Button mancinos = (Button) findViewById(R.id.button4);
        mancinos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToUrl("https://www.mancinosbigrapids.com/");
            }
        });

        // Create and link the button that lists my favorite foods from each of the four restaurants
        // This works by opening the fragment_secondary.xml file when clicked
        Button favorites = (Button) findViewById(R.id.button5);
        favorites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.fragment_secondary);
            }
        });
    }

    // Supporting function that allows the button to lead directly to the website when clicked
    public void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }
}